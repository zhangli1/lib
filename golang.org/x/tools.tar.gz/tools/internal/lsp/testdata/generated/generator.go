package generated

func _() {
	var x int //@diag("x", "LSP", "x declared but not used")
}
