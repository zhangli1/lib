package b

var c int //@rename("int", "uint")
