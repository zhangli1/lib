package imports //@import("package")

import "fmt"

func _() {
	fmt.Println("")
}