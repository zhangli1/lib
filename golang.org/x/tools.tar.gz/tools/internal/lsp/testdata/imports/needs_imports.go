package imports //@import("package")

func goodbye() {
	fmt.Printf("HI")
	log.Printf("byeeeee")
}
