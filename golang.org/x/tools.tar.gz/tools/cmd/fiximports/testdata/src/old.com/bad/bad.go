// This ill-formed Go source file is here to ensure the tool is robust
// against bad packages in the workspace.
